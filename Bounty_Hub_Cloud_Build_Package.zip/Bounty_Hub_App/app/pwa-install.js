(() => {
  let installPrompt = null;
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const addInstallButton = () => {
    if (isStandalone() || document.getElementById('pwaInstallButton')) return;
    const host = document.querySelector('.top-actions') || document.querySelector('.topbar-inner');
    if (!host) return;
    const button = document.createElement('button');
    button.id = 'pwaInstallButton';
    button.type = 'button';
    button.className = 'btn secondary';
    button.textContent = 'Установить';
    button.setAttribute('aria-label', 'Установить Bounty Hub');
    button.addEventListener('click', async () => {
      if (installPrompt) {
        installPrompt.prompt();
        await installPrompt.userChoice;
        installPrompt = null;
        button.remove();
        return;
      }
      const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
      alert(ios
        ? 'Чтобы установить Bounty Hub: нажми «Поделиться» в Safari, затем «На экран Домой».'
        : 'Открой меню браузера и выбери «Установить приложение» или «Добавить на главный экран».');
    });
    host.append(button);
  };
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
    addInstallButton();
  });
  window.addEventListener('appinstalled', () => document.getElementById('pwaInstallButton')?.remove());
  window.addEventListener('DOMContentLoaded', addInstallButton);
  if (document.readyState !== 'loading') addInstallButton();
})();
