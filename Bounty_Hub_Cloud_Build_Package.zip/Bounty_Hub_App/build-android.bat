@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Install Node.js LTS first: https://nodejs.org/ & pause & exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (
  echo Set ANDROID_HOME or ANDROID_SDK_ROOT to your Android SDK folder.
  echo Install Android Studio and the Android SDK first.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 (echo npm install failed.& pause & exit /b 1)
if not exist android\gradlew.bat call npx cap add android
if errorlevel 1 (echo Capacitor Android setup failed.& pause & exit /b 1)
call npx cap sync android
if errorlevel 1 (echo Capacitor sync failed.& pause & exit /b 1)
cd android
call gradlew.bat assembleDebug
if errorlevel 1 (echo Android build failed.& pause & exit /b 1)
echo.
echo DEBUG APK: android\app\build\outputs\apk\debug\app-debug.apk
echo This is a test APK, not a Play Store release build.
pause
