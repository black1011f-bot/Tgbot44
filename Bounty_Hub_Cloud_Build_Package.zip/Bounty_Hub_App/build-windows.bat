@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Install Node.js LTS first: https://nodejs.org/ & pause & exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed.& pause & exit /b 1)
call npm run dist:win
if errorlevel 1 (echo Windows build failed.& pause & exit /b 1)
echo.
echo Done. Installer is in the release folder.
pause
