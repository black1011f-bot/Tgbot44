NEON LEGENDS — WINTER EDITION v6.0

Это новый исходный ZIP для текущего GitHub Actions workflow репозитория Tgbot44.
Внутри находится папка Bounty_Hub_App с package.json и веб-приложением для Capacitor.

ЗАМЕНА В GITHUB
1. Открой black1011f-bot/Tgbot44 → файл BOUNTY_HUB_NEON_LEGENDS_V5_SOURCE.zip.
2. Удали старый ZIP или загрузи этот архив с тем же именем через Replace/Заменить.
3. Не оставляй оба архива рядом: текущий workflow берёт первый найденный ZIP.
4. После загрузки открой Actions → Build Bounty Hub APK.
5. В последнем запуске открой Artifacts → Bounty-Hub-APK, скачай ZIP и распакуй APK.

Если Actions не стартует автоматически после замены, нажми Actions → Build Bounty Hub APK → Run workflow.

Важно: этот архив — исходники для сборки, не APK. Сборка выполняется GitHub Actions.
