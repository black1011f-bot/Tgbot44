(function () {
  'use strict';

  const STORAGE_KEY = 'neon-legends-winter-v6';
  const $ = (selector, root = document) => root.querySelector(selector);
  const esc = (value) => String(value).replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  const rand = (max) => Math.floor(Math.random() * max);
  const pick = (arr) => arr[rand(arr.length)];
  const defaultState = {
    page: 'home', playerName: 'Majorka', playerLevel: 12, playerXp: 1242,
    gems: 1250, coins: 8420, passLevel: 12, passXp: 1242, premium: false,
    claimed: { free: [], premium: [] }, inventory: ['Зимний значок'], equipped: 'Эльфийка',
    wins: 0, gamesPlayed: 0, botChat: [
      { name: 'MikuChan', text: 'Кто пойдёт в Шпиона? ❄' },
      { name: 'Sakura', text: 'Я уже готова к зимнему событию!' }
    ],
    settings: { sound: true, particles: true, compact: false },
    game: null
  };
  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return structuredClone(defaultState);
      const data = JSON.parse(raw);
      return { ...structuredClone(defaultState), ...data,
        claimed: { ...defaultState.claimed, ...(data.claimed || {}) },
        inventory: Array.isArray(data.inventory) ? data.inventory : [...defaultState.inventory],
        settings: { ...defaultState.settings, ...(data.settings || {}) }
      };
    } catch (_) { return structuredClone(defaultState); }
  }
  let state = loadState();
  let toastTimer = null;
  function save() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) {} }
  function toast(message) {
    const el = $('#toast'); if (!el) return;
    el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
  }
  function xpPercent() { return clamp((state.playerXp / 3000) * 100, 0, 100); }
  function addXp(amount) {
    state.playerXp += amount; state.passXp += amount;
    while (state.playerXp >= 3000) { state.playerXp -= 3000; state.playerLevel += 1; toast(`Новый уровень игрока: ${state.playerLevel}!`); }
    while (state.passXp >= 3000 && state.passLevel < 50) { state.passXp -= 3000; state.passLevel += 1; toast(`Боевой пропуск: уровень ${state.passLevel}!`); }
    state.passLevel = clamp(state.passLevel, 1, 50);
  }
  function grantGameReward(win, note) {
    if (!state.game || state.game.rewarded) return;
    state.game.rewarded = true; state.gamesPlayed += 1;
    if (win) {
      state.wins += 1; state.coins += 180; state.gems += 15; addXp(120);
      state.game.resultText = `${note} Награда: +180 монет, +15 кристаллов, +120 опыта.`;
    } else {
      state.coins += 45; addXp(40);
      state.game.resultText = `${note} За участие: +45 монет и +40 опыта.`;
    }
    save();
  }
  const navItems = [
    ['home','⌂','Главная'],['games','🎮','Игры'],['characters','✦','Персонажи'],
    ['shop','🛒','Магазин'],['pass','♛','Пропуск'],['achievements','🏆','Достижения'],['settings','⚙','Настройки']
  ];
  function shell(content) {
    return `<div class="app-shell">
      <header class="topbar">
        <div class="brand-mark"><b>NEON LEGENDS</b><span>Winter Edition</span></div>
        <button class="player-chip" data-action="navigate" data-page="profile" aria-label="Профиль">
          <span class="avatar">❄</span><span class="player-info"><strong>${esc(state.playerName)} 👑</strong><small>Lv. ${state.playerLevel} · ${state.playerXp} / 3000 XP</small><span class="xp-mini"><i style="width:${xpPercent()}%"></i></span></span>
        </button>
        <div class="resources"><div class="resource"><span class="gem">♦</span>${state.gems.toLocaleString('ru-RU')}<button data-action="navigate" data-page="shop">＋</button></div><div class="resource"><span class="coin">✦</span>${state.coins.toLocaleString('ru-RU')}<button data-action="navigate" data-page="shop">＋</button></div></div>
        <div class="top-actions"><button class="icon-button" data-action="navigate" data-page="events" title="Подарки">🎁</button><button class="icon-button" data-action="navigate" data-page="chat" title="Сообщения">✉<i class="dot"></i></button><button class="icon-button" data-action="navigate" data-page="rooms" title="Комната с ботами">♟</button><button class="icon-button" data-action="navigate" data-page="profile" title="Профиль">◉</button></div>
      </header>
      <aside class="sidebar">${navItems.map(([page,icon,label]) => `<button class="nav-btn ${state.page===page?'active':''}" data-action="navigate" data-page="${page}"><span class="nav-icon">${icon}</span><span>${label}</span></button>`).join('')}<div class="nav-spacer"></div><div class="nav-foot">LOCAL BOT SEASON<br>v6.0 · OFFLINE</div></aside>
      <main class="main-area"><div class="page">${content}</div></main>
    </div>`;
  }
  function rewardFor(level, track) {
    const free = [
      ['♦','100 крист.','gems',100],['🖼','Рамка','frame',0],['👑','Аватар','avatar',0],['🎟','2 билета','ticket',2],['🎁','Сундук','chest',1],
      ['✦','250 монет','coins',250],['❄','Эмблема','badge',0],['♦','150 крист.','gems',150],['🧪','Эликсир','potion',1],['🎁','Сундук','chest',1]
    ];
    const premium = [
      ['♦','300 крист.','gems',300],['👗','Костюм','costume',0],['💎','300 монет','coins',300],['🎟','5 билетов','ticket',5],['👑','Редкий образ','skin',0],
      ['🎀','Аксессуар','item',0],['♦','500 крист.','gems',500],['🧸','Питомец','pet',0],['🎁','Мега-сундук','chest',2],['🌟','SSR-образ','skin',0]
    ];
    const arr = track === 'premium' ? premium : free;
    const idx = (level - 1) % arr.length;
    const [emoji,name,type,value] = arr[idx];
    return { emoji, name, type, value };
  }
  function rewardMini(level, track) {
    const reward = rewardFor(level, track);
    const claimed = state.claimed[track].includes(level);
    const unlocked = level <= state.passLevel && (track !== 'premium' || state.premium);
    return `<div class="reward-mini ${unlocked?'':'locked'}"><b>УР. ${level}</b><span class="reward-emoji">${reward.emoji}</span><small>${claimed?'Забрано':reward.name}</small></div>`;
  }
  function renderHome() {
    const preview = [1,5,10,15,20].map(n => rewardMini(n,'free')).join('');
    return `<div class="home-page"><div class="home-top">
      <section class="hero-panel"><div class="hero-content"><div class="edition-label">❄ СЕЗОННОЕ СОБЫТИЕ · WINTER EDITION</div><h1 class="hero-title">NEON<br>LEGENDS</h1><p class="hero-sub">Твоя зимняя легенда начинается здесь.</p><div class="event-banner"><span style="font-size:22px">❄</span><div><b>Новогоднее событие!</b><small>Зимняя сказка · награды каждый день</small></div></div><div class="hero-spacer"></div><div class="hero-actions"><button class="primary-btn" data-action="navigate" data-page="games">▶ ИГРАТЬ</button><button class="soft-btn" data-action="navigate" data-page="characters">✦ Персонажи</button></div><div class="hero-status">● Офлайн-режим с ботами доступен · Сетевая игра появится позже</div></div></section>
      <section class="panel pass-mini"><div class="pass-head"><span class="crown">♛</span><div><strong>Боевой пропуск</strong><small>Сезон: Зимняя сказка · 50 уровней</small></div><button class="soft-btn" data-action="navigate" data-page="pass">Открыть</button></div><div class="pass-level"><div class="level-number">${state.passLevel}</div><div class="level-progress"><div><b>Lv. ${state.passLevel}</b><span>${state.passXp} / 3000</span></div><div class="progress-track"><i style="width:${clamp(state.passXp/30,0,100)}%"></i></div></div></div><div class="pass-tabs"><button class="pass-tab active free" data-action="navigate" data-page="pass" data-track="free">❄ Бесплатный</button><button class="pass-tab premium" data-action="navigate" data-page="pass" data-track="premium">♛ Премиум</button></div><div class="mini-rewards">${preview}</div><div class="pass-mini-foot"><button class="gold-btn" data-action="navigate" data-page="pass">🎁 Забрать награды</button><button class="soft-btn" data-action="navigate" data-page="events">События</button></div></section>
      </div><div class="game-strip">${[
        ['spy','🕵️','Шпион','Найди шпиона среди ботов'],['crocodile','🐊','Крокодил','Угадай рисунок'],['bunker','☢️','Бункер','Выживи и голосуй'],['munchkin','⚔️','Манчкин','Победи монстра']
      ].map(([id,emoji,name,desc])=>`<button class="game-tile" data-action="start-game" data-game="${id}"><span class="game-emoji">${emoji}</span><span><strong>${name}</strong><small>${desc}</small></span></button>`).join('')}</div></div>`;
  }
  function renderGames() {
    const games = [
      ['spy','🕵️','Шпион','Угадай, кто шпион. Случайные роли, подсказки и голосование против ботов.'],
      ['crocodile','🐊','Крокодил','Смотри на рисунок бота и выбери правильное слово до конца раунда.'],
      ['bunker','☢️','Бункер','Открывай характеристики, принимай решения и выбирай, кто останется в убежище.'],
      ['munchkin','⚔️','Манчкин','Пошаговая битва с монстрами: атака, защита, навыки и зелья.']
    ];
    return `<div class="games-page"><div class="page-header"><div><h1>🎮 Игры</h1><p>Четыре режима · играй с локальными ботами</p></div><span class="spacer"></span><span class="pill">БОТЫ · OFFLINE</span></div><div class="games-grid">${games.map(([id,emoji,name,desc])=>`<section class="panel game-card"><span class="big-emoji">${emoji}</span><div><h3>${name}</h3><p>${desc}</p></div><button class="primary-btn play-btn" data-action="start-game" data-game="${id}">Играть ▶</button></section>`).join('')}</div><section class="panel online-note"><span style="font-size:20px">🌐</span><div><b>Сетевая игра с реальными игроками — следующий этап.</b><br>Сейчас работают локальные матчи с ботами. Для онлайна потребуется подключить сервер и авторизацию.</div></section></div>`;
  }
  function renderGame() {
    const g = state.game;
    if (!g) return `<div class="page-header"><div><h1>Выбери игру</h1><p>Локальные матчи с ботами</p></div></div>${renderGames()}`;
    const back = `<div class="page-header"><button class="soft-btn" data-action="navigate" data-page="games">← Все игры</button><span class="pill">МАТЧ С БОТАМИ</span><span class="spacer"></span><button class="soft-btn" data-action="start-game" data-game="${g.type}">↻ Новый раунд</button></div>`;
    if (g.type === 'spy') return back + renderSpy(g);
    if (g.type === 'crocodile') return back + renderCrocodile(g);
    if (g.type === 'bunker') return back + renderBunker(g);
    if (g.type === 'munchkin') return back + renderMunchkin(g);
    return back;
  }
  function renderSpy(g) {
    const names = g.players.map((p,i)=>`<div class="bot-row"><span class="bot-avatar">${p.avatar}</span><b>${esc(p.name)}</b><small>${i===0?'Ты':'Бот'}</small></div>`).join('');
    let body = '';
    if (g.phase === 'reveal') body = `<div class="game-question">${g.userSpy?'🕵️ Ты — шпион!':'📍 Ты мирный игрок'}</div><p class="muted">${g.userSpy?'Локация скрыта. Прочитай подсказки ботов и попробуй угадать место.':'Твоя локация: '+esc(g.location)+'. Найди игрока, которому не хватает информации.'}</p><button class="primary-btn" data-action="spy-next">Перейти к раунду →</button>`;
    else if (g.phase === 'investigate' && !g.userSpy) body = `<div class="game-question">Кто ведёт себя подозрительно?</div><p class="muted">Прочитай короткие реплики игроков и выбери шпиона.</p><div class="game-options">${g.players.slice(1).map((p,i)=>`<button class="option-btn" data-action="spy-vote" data-index="${i+1}"><b>${p.avatar} ${esc(p.name)}</b><br><small class="muted">${esc(g.clues[i])}</small></button>`).join('')}</div>`;
    else if (g.phase === 'investigate' && g.userSpy) body = `<div class="game-question">Угадай секретную локацию</div><p class="muted">Боты оставили подсказки. Выбери место, где проходит раунд.</p><div class="clue-list">${g.clues.map((clue,i)=>`<div class="bot-row"><span class="bot-avatar">${botNames[i]?.avatar||'💬'}</span><span>${esc(clue)}</span></div>`).join('')}</div><div class="game-options">${g.locationOptions.map(loc=>`<button class="option-btn" data-action="spy-guess" data-location="${esc(loc)}">📍 ${esc(loc)}</button>`).join('')}</div>`;
    else body = `<div class="game-question">${g.resultWin?'✨ Победа!':'Раунд завершён'}</div><p class="muted">${esc(g.resultText || '')}</p><button class="primary-btn" data-action="start-game" data-game="spy">Играть ещё раз ↻</button>`;
    return `<div class="game-layout"><section class="panel game-main"><div class="panel-title"><span>🕵️ Шпион</span><small>Раунд 1/1 · 00:45</small></div>${body}</section><aside class="panel game-side"><div class="panel-title">Игроки <small>6/6</small></div>${names}<p class="muted" style="font-size:9px;margin-top:12px">Роли и шпион выбираются случайно в начале каждого матча.</p></aside></div>`;
  }
  function renderCrocodile(g) {
    const body = g.phase === 'guess' ? `<div class="game-question">Угадай рисунок бота!</div><div style="display:flex;align-items:center;justify-content:center;min-height:100px;border:1px solid rgba(191,138,255,.35);border-radius:15px;background:radial-gradient(circle,#4b247b,#13092f);font-size:clamp(52px,8vw,86px);text-shadow:0 0 25px #d06aff">${g.drawing}</div><p class="muted">Подсказка: ${esc(g.hint)}</p><div class="game-options">${g.options.map(word=>`<button class="option-btn" data-action="croc-guess" data-word="${esc(word)}">${esc(word)}</button>`).join('')}</div>` : `<div class="game-question">${g.win?'🎉 Правильно!':'Попробуй ещё раз!'}</div><p class="muted">Правильный ответ: <b>${esc(g.word)}</b>. ${g.resultText||''}</p><button class="primary-btn" data-action="start-game" data-game="crocodile">Следующий рисунок →</button>`;
    return `<div class="game-layout"><section class="panel game-main"><div class="panel-title"><span>🐊 Крокодил</span><small>Время раунда: 00:45</small></div>${body}</section><aside class="panel game-side"><div class="panel-title">Как играть</div><p class="muted" style="font-size:10px;line-height:1.6">Бот показывает рисунок и даёт подсказку. Выбери слово из четырёх вариантов. За правильный ответ получишь опыт и монеты.</p><div class="bot-row"><span class="bot-avatar">🐊</span><b>Рисует: MikuChan</b><small>готово</small></div><div class="bot-row"><span class="bot-avatar">🎨</span><b>Подсказка</b><small>активна</small></div></aside></div>`;
  }
  function renderBunker(g) {
    let body = '';
    if (!g.finished) body = `<div class="game-question">День ${g.day} · Выбирай, кого исключить</div><p class="muted">В убежище осталось ${g.survivors.length} кандидатов. Твой голос влияет на результат дня.</p><div class="game-options">${g.survivors.filter(p=>!p.you).map(p=>`<button class="option-btn" data-action="bunker-vote" data-id="${p.id}"><b>${p.avatar} ${esc(p.name)}</b><br><small class="muted">${esc(p.trait)}</small></button>`).join('')}</div>`;
    else body = `<div class="game-question">${g.win?'🏆 Ты выжил!':'☃ Раунд окончен'}</div><p class="muted">${esc(g.resultText||'')}</p><div class="game-options">${g.survivors.map(p=>`<div class="option-btn">${p.avatar} <b>${esc(p.name)}</b><br><small class="muted">${esc(p.trait)}</small></div>`).join('')}</div><button class="primary-btn" data-action="start-game" data-game="bunker">Начать заново ↻</button>`;
    return `<div class="game-layout"><section class="panel game-main"><div class="panel-title"><span>☢️ Бункер</span><small>День ${Math.min(g.day,4)}/4</small></div>${body}</section><aside class="panel game-side"><div class="panel-title">Условия бункера</div><p class="muted" style="font-size:10px;line-height:1.6">⏳ Запасов хватит на 4 дня.<br>🧊 Нужны медицина, инженер и повар.<br>🚪 Оставьте самых полезных кандидатов.</p><div class="bot-row"><span class="bot-avatar">🧑‍🚀</span><b>Твоя цель</b><small>выжить</small></div><div class="bot-row"><span class="bot-avatar">🗳️</span><b>Голосование</b><small>1 голос/день</small></div></aside></div>`;
  }
  function renderMunchkin(g) {
    const playerHp = Math.max(0,g.hp), enemyHp = Math.max(0,g.enemy.hp);
    const body = g.finished ? `<div class="game-question">${g.win?'🏆 Монстр повержен!':'💥 Ты проиграл бой'}</div><p class="muted">${esc(g.resultText||'')}</p><button class="primary-btn" data-action="start-game" data-game="munchkin">Новый бой ↻</button>` : `<div class="versus"><div class="fighter"><div style="font-size:56px">🧙‍♀️</div><b>Majorka</b><div class="hp"><i style="width:${playerHp/120*100}%;background:#4ee4aa"></i></div><small>${playerHp}/120 HP · ур. ${g.level}</small></div><div class="versus-label">VS</div><div class="fighter"><div style="font-size:56px">${g.enemy.emoji}</div><b>${esc(g.enemy.name)}</b><div class="hp"><i style="width:${enemyHp/g.enemy.max*100}%;background:#ff647e"></i></div><small>${enemyHp}/${g.enemy.max} HP</small></div></div><p class="muted">${esc(g.log||'Выбери действие.')}</p><div class="game-options"><button class="option-btn" data-action="munchkin-hit">⚔️ Атака</button><button class="option-btn" data-action="munchkin-block">🛡 Защита</button><button class="option-btn" data-action="munchkin-skill">✨ Навык</button><button class="option-btn" data-action="munchkin-potion" ${g.potions<1?'disabled':''}>🧪 Зелье (${g.potions})</button></div>`;
    return `<div class="game-layout"><section class="panel game-main"><div class="panel-title"><span>⚔️ Манчкин</span><small>Уровень героя: ${g.level} · ход ${g.turn}</small></div>${body}</section><aside class="panel game-side"><div class="panel-title">Снаряжение</div><div class="bot-row"><span class="bot-avatar">🗡️</span><b>Ледяной клинок</b><small>+4 атаки</small></div><div class="bot-row"><span class="bot-avatar">🛡️</span><b>Снежная броня</b><small>+3 защиты</small></div><div class="bot-row"><span class="bot-avatar">🧪</span><b>Зелья здоровья</b><small>${g.potions}</small></div><p class="muted" style="font-size:9px;line-height:1.5">Атакуй монстра, блокируй его удары, используй навык и зелья. Победа приносит монеты и опыт.</p></aside></div>`;
  }
  function renderPass() {
    const page = state.passPage || 0;
    const start = page * 10 + 1;
    const free = Array.from({length:10},(_,i)=>passRewardCard(start+i,'free')).join('');
    const prem = Array.from({length:10},(_,i)=>passRewardCard(start+i,'premium')).join('');
    return `<div class="pass-page"><div class="page-header"><div><h1>♛ Боевой пропуск</h1><p>Сезон: Зимняя сказка · 50 уровней наград</p></div><span class="spacer"></span>${state.premium?'<span class="pill">ПРЕМИУМ АКТИВЕН</span>':'<button class="gold-btn" data-action="buy-premium">♛ Купить премиум · 600 ♦</button>'}</div>
      <section class="panel pass-overview"><div class="pass-big-level">${state.passLevel}</div><div class="progress-wrap"><div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:7px"><b>Уровень ${state.passLevel} / 50</b><span>${state.passXp} / 3000 XP</span></div><div class="progress-track" style="height:10px"><i style="width:${clamp(state.passXp/30,0,100)}%"></i></div><small class="muted" style="font-size:9px">Играй в режимы с ботами и получай опыт пропуска.</small></div><div class="pass-page-actions"><button class="primary-btn" data-action="claim-all">🎁 Забрать доступные</button></div></section>
      <div class="pager">${Array.from({length:5},(_,i)=>`<button class="${page===i?'active':''}" data-action="pass-page" data-page-index="${i}">${i*10+1}–${i*10+10}</button>`).join('')}</div>
      <section id="free-track" class="panel" style="padding:10px"><div class="panel-title" style="margin:0 0 8px">❄ Бесплатная линия <small>доступна всем</small></div><div class="pass-grid">${free}</div></section>
      <section id="premium-track" class="panel" style="padding:10px"><div class="panel-title" style="margin:0 0 8px">👑 Премиум-линия <small>${state.premium?'доступна':'закрыта до покупки'}</small></div><div class="pass-grid">${prem}</div></section>
      <p class="muted" style="font-size:9px">Награды сохраняются на этом устройстве. Покупка премиума в этой версии — внутриигровая разблокировка за кристаллы, не реальный платёж.</p></div>`;
  }
  function passRewardCard(level, track) {
    const reward = rewardFor(level,track), claimed = state.claimed[track].includes(level);
    const unlocked = level <= state.passLevel && (track==='free' || state.premium);
    return `<button class="pass-reward ${track==='premium'?'premium':''} ${claimed?'claimed':''} ${unlocked?'':'locked'}" data-action="claim-reward" data-track="${track}" data-level="${level}" title="${esc(reward.name)}"><span class="lvl">Ур. ${level}</span><span class="emoji">${reward.emoji}</span><small>${claimed?'Забрано':reward.name}</small>${claimed?'<span class="claim-mark">✓</span>':(!unlocked?'<span class="claim-mark">🔒</span>':'')}</button>`;
  }
  const characters = [
    {name:'Эльфийка',rarity:'SSR',emoji:'🧝‍♀️',desc:'Ледяная магия',power:96},
    {name:'Демонесса',rarity:'SR',emoji:'😈',desc:'Тёмный огонь',power:88},
    {name:'Кошкодевочка',rarity:'SR',emoji:'🐱',desc:'Снежная ловкость',power:85},
    {name:'Рыцарь',rarity:'R',emoji:'🛡️',desc:'Стальная защита',power:74},
    {name:'Снегурочка',rarity:'SSR',emoji:'❄️',desc:'Зимний саппорт',power:94},
    {name:'Маг',rarity:'R',emoji:'🧙',desc:'Сила стихий',power:78},
    {name:'Тень',rarity:'SR',emoji:'🥷',desc:'Тихий удар',power:87},
    {name:'Мику',rarity:'R',emoji:'🎀',desc:'Поддержка команды',power:73}
  ];
  function renderCharacters() {
    return `<div class="page-header"><div><h1>✦ Персонажи</h1><p>Коллекция героев и костюмов</p></div><span class="spacer"></span><span class="pill">Найдено: ${characters.length} / 120</span></div><div class="character-grid">${characters.map(c=>`<button class="panel character-card" data-action="select-character" data-name="${esc(c.name)}"><span class="rarity">${c.rarity}</span><div class="character-art">${c.emoji}</div><strong>${esc(c.name)}</strong><small>${esc(c.desc)} · Сила ${c.power}</small>${state.equipped===c.name?'<span class="pill" style="display:inline-block;margin-top:6px;color:#6ce9bb">Выбран</span>':''}</button>`).join('')}</div>`;
  }
  const shopItems = [
    {id:'gem-pack',name:'Кристаллы ×300',emoji:'♦',price:650,currency:'coins',desc:'Пополнение валюты'},
    {id:'winter-chest',name:'Зимний сундук',emoji:'🎁',price:900,currency:'coins',desc:'Случайная награда'},
    {id:'snow-costume',name:'Костюм «Снег»',emoji:'👗',price:800,currency:'gems',desc:'Косметический образ'},
    {id:'pet-fox',name:'Питомец-лис',emoji:'🦊',price:500,currency:'gems',desc:'Спутник героя'},
    {id:'ice-frame',name:'Рамка «Лёд»',emoji:'🖼️',price:300,currency:'coins',desc:'Оформление профиля'},
    {id:'gold-box',name:'Золотой ящик',emoji:'💎',price:1200,currency:'coins',desc:'Содержит ценные вещи'}
  ];
  function renderShop() {
    return `<div class="page-header"><div><h1>🛒 Магазин</h1><p>Покупки за внутриигровые монеты и кристаллы</p></div><span class="spacer"></span><span class="pill">Без реальных платежей</span></div><div class="store-grid">${shopItems.map(item=>`<section class="panel store-card"><div class="item-art">${item.emoji}</div><strong>${item.name}</strong><small>${item.desc}</small><button class="primary-btn" data-action="shop-buy" data-id="${item.id}">${item.price} ${item.currency==='gems'?'♦':'✦'}</button></section>`).join('')}</div>`;
  }
  function renderAchievements() {
    const list = [
      ['🏆','Первая победа','Выиграй первый матч',state.wins>=1?'1 / 1':`${state.wins} / 1`,state.wins>=1],
      ['🎮','Игрок','Сыграй 10 матчей',`${state.gamesPlayed} / 10`,state.gamesPlayed>=10],
      ['❄','Зимняя легенда','Достигни 15 уровня пропуска',`${state.passLevel} / 15`,state.passLevel>=15],
      ['💎','Богатство','Накопи 2000 кристаллов',`${state.gems} / 2000`,state.gems>=2000],
      ['⚔️','Охотник','Победи 5 монстров','0 / 5',false],
      ['👑','Премиум','Открой премиум-пропуск',state.premium?'1 / 1':'0 / 1',state.premium]
    ];
    return `<div class="page-header"><div><h1>🏆 Достижения</h1><p>Твои цели и награды</p></div></div><div class="achievements">${list.map(([icon,name,desc,progress,done])=>`<section class="panel achievement"><span class="medal">${icon}</span><div><strong>${name} ${done?'✓':''}</strong><small>${desc} · ${progress}</small></div></section>`).join('')}</div>`;
  }
  function renderProfile() {
    return `<div class="page-header"><div><h1>Профиль игрока</h1><p>Локальный профиль на этом устройстве</p></div></div><div class="profile-layout"><section class="panel profile-card"><div class="profile-avatar">❄</div><h2>${esc(state.playerName)} 👑</h2><p>Уровень ${state.playerLevel} · NEON LEGENDS</p><div class="progress-track" style="margin:12px 0"><i style="width:${xpPercent()}%"></i></div><p>${state.playerXp} / 3000 XP</p><button class="soft-btn" data-action="rename">Изменить ник</button></section><div class="stats-grid"><section class="panel stat-box"><strong>${state.wins}</strong><small>Победы</small></section><section class="panel stat-box"><strong>${state.gamesPlayed}</strong><small>Матчи</small></section><section class="panel stat-box"><strong>${state.gems.toLocaleString('ru-RU')}</strong><small>Кристаллы</small></section><section class="panel stat-box"><strong>${state.coins.toLocaleString('ru-RU')}</strong><small>Монеты</small></section><section class="panel stat-box"><strong>${state.inventory.length}</strong><small>Предметы</small></section><section class="panel stat-box"><strong>${state.equipped}</strong><small>Выбранный персонаж</small></section></div></div>`;
  }
  function renderSettings() {
    const rows = [['sound','🔊 Звук','Игровые звуки'],['particles','✨ Эффекты','Снежные частицы'],['compact','▦ Компактный режим','Уменьшить декоративные эффекты']];
    return `<div class="page-header"><div><h1>⚙ Настройки</h1><p>Настройки приложения и локального сохранения</p></div></div><div class="settings-list">${rows.map(([id,title,desc])=>`<section class="panel setting-row"><div><strong>${title}</strong><small>${desc}</small></div><button class="toggle ${state.settings[id]?'on':''}" data-action="toggle-setting" data-setting="${id}">${state.settings[id]?'ВКЛ':'ВЫКЛ'}</button></section>`).join('')}<section class="panel setting-row"><div><strong>Ориентация</strong><small>Игра рассчитана на горизонтальный экран</small></div><span class="pill">LANDSCAPE</span></section><section class="panel setting-row"><div><strong>Сохранение</strong><small>Прогресс хранится локально на телефоне</small></div><span class="pill">LOCAL</span></section><section class="panel setting-row"><div><strong>Сбросить прогресс</strong><small>Удалит локальный уровень, валюту и награды</small></div><button class="danger-btn" data-action="confirm-reset">Сброс</button></section></div>`;
  }
  function renderEvents() {
    return `<div class="page-header"><div><h1>🎁 События и подарки</h1><p>Зимняя сказка · задания этого сезона</p></div></div><div class="store-grid"><section class="panel store-card"><div class="item-art">🎄</div><strong>Зимний вход</strong><small>Ежедневный подарок за посещение</small><button class="gold-btn" data-action="daily-reward">Забрать подарок</button></section><section class="panel store-card"><div class="item-art">❄️</div><strong>Снежный вызов</strong><small>Сыграй один матч с ботами</small><button class="primary-btn" data-action="navigate" data-page="games">Играть</button></section><section class="panel store-card"><div class="item-art">👑</div><strong>Пропуск сезона</strong><small>50 уровней бесплатных и премиум наград</small><button class="primary-btn" data-action="navigate" data-page="pass">Открыть</button></section></div>`;
  }
  function renderRooms() {
    const bots = [['🌸','Sakura'],['🦊','KillerFox'],['🎀','MikuChan'],['🌙','Rin']];
    return `<div class="page-header"><div><h1>♟ Комната с ботами</h1><p>Локальное лобби для тренировки</p></div><span class="spacer"></span><span class="pill">4/5 готовы</span></div><div class="game-layout"><section class="panel game-main"><div class="panel-title">AnimeRoom-8427 <small>Закрытая локальная комната</small></div><p class="muted" style="font-size:10px">Выбери режим и начни матч с ботами. Приглашения реальных игроков пока отключены.</p><div class="game-options"><button class="option-btn" data-action="start-game" data-game="spy">🕵️ Шпион</button><button class="option-btn" data-action="start-game" data-game="crocodile">🐊 Крокодил</button><button class="option-btn" data-action="start-game" data-game="bunker">☢️ Бункер</button><button class="option-btn" data-action="start-game" data-game="munchkin">⚔️ Манчкин</button></div><button class="primary-btn" style="margin-top:15px" data-action="start-game" data-game="spy">Начать игру ▶</button></section><aside class="panel game-side"><div class="panel-title">Участники <small>локальные боты</small></div>${bots.map(([icon,name])=>`<div class="bot-row"><span class="bot-avatar">${icon}</span><b>${name}</b><small style="color:#69e8b6">Готов</small></div>`).join('')}<div class="bot-row"><span class="bot-avatar">❄</span><b>${esc(state.playerName)}</b><small style="color:#69e8b6">Хозяин</small></div></aside></div>`;
  }
  function renderChat() {
    return `<div class="page-header"><div><h1>✉ Чат</h1><p>Локальные сообщения с ботами · реальный онлайн-чат появится после подключения сервера</p></div></div><section class="panel chat-box"><div class="chat-messages">${state.botChat.map(msg=>`<div class="chat-msg ${msg.name==='Ты'?'me':''}"><small>${esc(msg.name)}</small>${esc(msg.text)}</div>`).join('')}</div><form class="chat-form" id="chatForm"><input id="chatInput" maxlength="180" placeholder="Написать сообщение..." autocomplete="off"><button class="primary-btn" type="submit">Отправить ➤</button></form></section>`;
  }
  function renderPage() {
    if (state.page === 'home') return renderHome();
    if (state.page === 'games') return renderGames();
    if (state.page === 'game') return renderGame();
    if (state.page === 'pass') return renderPass();
    if (state.page === 'characters') return renderCharacters();
    if (state.page === 'shop') return renderShop();
    if (state.page === 'achievements') return renderAchievements();
    if (state.page === 'profile') return renderProfile();
    if (state.page === 'settings') return renderSettings();
    if (state.page === 'events') return renderEvents();
    if (state.page === 'rooms') return renderRooms();
    if (state.page === 'chat') return renderChat();
    return renderHome();
  }
  function render() { $('#app').innerHTML = shell(renderPage()); }
  function navigate(page) { state.page = page; save(); render(); }

  const locations = ['Космическая станция','Горнолыжный курорт','Секретная лаборатория','Новогодняя ярмарка','Подводный город','Замок вампиров','Полярная станция','Лунная база'];
  const botNames = [{name:'Sakura',avatar:'🌸'},{name:'Rin',avatar:'🌙'},{name:'MikuChan',avatar:'🎀'},{name:'KillerFox',avatar:'🦊'},{name:'Zero',avatar:'🕶️'}];
  function startGame(type) {
    if (type === 'spy') {
      const location = pick(locations), spyIndex = rand(6), players = [{name:state.playerName,avatar:'❄',you:true},...botNames];
      const clueByLocation = { 'Космическая станция':'Здесь без скафандра долго не проживёшь.', 'Горнолыжный курорт':'Не забудь лыжи и тёплые перчатки.', 'Секретная лаборатория':'Лучше ничего не трогать без разрешения.', 'Новогодняя ярмарка':'Пахнет корицей, сладостями и хвоей.', 'Подводный город':'Вокруг вода, а воздух поступает по трубам.', 'Замок вампиров':'Солнце здесь — большая редкость.', 'Полярная станция':'Ветер, лёд и очень длинная ночь.', 'Лунная база':'Здесь низкая гравитация и серый грунт.' };
      const clues = [clueByLocation[location],'Тут всегда много людей.','Я бы взял с собой тёплую куртку.','Здесь часто слышно странные звуки.','Главное — не потерять пропуск.'];
      state.game = {type,phase:'reveal',players,location,spyIndex,userSpy:spyIndex===0,clues:clues.sort(()=>Math.random()-.5),locationOptions:[location,...locations.filter(x=>x!==location).sort(()=>Math.random()-.5).slice(0,3)].sort(()=>Math.random()-.5)};
    } else if (type === 'crocodile') {
      const items = [
        {word:'Панда',drawing:'🐼',hint:'Чёрно-белый мишка, который любит бамбук.'},
        {word:'Космос',drawing:'🚀🌙',hint:'Звёзды, планеты и огромная вселенная.'},
        {word:'Пицца',drawing:'🍕',hint:'Круглое блюдо с сыром и начинкой.'},
        {word:'Снеговик',drawing:'⛄❄️',hint:'Зимний персонаж из снега и морковки.'},
        {word:'Самолёт',drawing:'✈️☁️',hint:'Летает высоко в небе и перевозит людей.'},
        {word:'Кот',drawing:'🐈‍⬛',hint:'Домашнее животное, которое мурлычет.'}
      ];
      const item = pick(items); const wrong = items.filter(x=>x.word!==item.word).sort(()=>Math.random()-.5).slice(0,3).map(x=>x.word);
      state.game = {type,phase:'guess',...item,options:[item.word,...wrong].sort(()=>Math.random()-.5)};
    } else if (type === 'bunker') {
      const cast = [
        {id:1,name:'Sakura',avatar:'🌸',trait:'Врач · 28 лет · умеет выращивать еду'},
        {id:2,name:'Rin',avatar:'🌙',trait:'Инженер · 32 года · боится темноты'},
        {id:3,name:'KillerFox',avatar:'🦊',trait:'Повар · 26 лет · отличная память'},
        {id:4,name:'Zero',avatar:'🕶️',trait:'Пилот · 41 год · хроническая усталость'},
        {id:5,name:'MikuChan',avatar:'🎀',trait:'Учёный · 24 года · знает медицину'},
        {id:6,name:state.playerName,avatar:'❄',you:true,trait:'Выживальщик · 25 лет · умеет чинить технику'}
      ];
      state.game = {type,day:1,survivors:cast,finished:false};
    } else if (type === 'munchkin') {
      const enemy = pick([{name:'Гоблин',emoji:'👹',hp:80},{name:'Ледяной тролль',emoji:'🧌',hp:105},{name:'Скелет-рыцарь',emoji:'💀',hp:95},{name:'Снежный демон',emoji:'👿',hp:125}]);
      state.game = {type,level:3,hp:120,enemy:{...enemy,max:enemy.hp},potions:2,turn:1,block:0,skillReady:true,finished:false,log:'Монстр вышел на тропу. Твой ход.'};
    }
    state.page = 'game'; save(); render();
  }
  function finishGame(win, note) {
    if (!state.game || state.game.rewarded) return;
    state.game.finished = true; state.game.win = win; grantGameReward(win,note); render();
  }
  function spyNext() { if (state.game?.type==='spy' && state.game.phase==='reveal') { state.game.phase='investigate'; render(); } }
  function spyVote(index) {
    const g=state.game; if (!g || g.type!=='spy' || g.phase!=='investigate') return;
    const correct = Number(index)===g.spyIndex; g.phase='result'; g.resultWin=correct;
    g.resultText=correct?`Верно! Шпионом был ${g.players[index].name}.`:`Не угадал. Шпион — ${g.players[g.spyIndex].name}.`;
    finishGame(correct,g.resultText);
  }
  function spyGuess(location) {
    const g=state.game; if (!g || g.type!=='spy' || !g.userSpy) return;
    const correct=location===g.location; g.phase='result'; g.resultWin=correct;
    g.resultText=correct?`Ты вычислил место: ${location}. Боты не раскрыли тебя!`:`Это было не то место. Правильный ответ: ${g.location}.`;
    finishGame(correct,g.resultText);
  }
  function crocGuess(word) {
    const g=state.game; if (!g || g.type!=='crocodile') return;
    const win=word===g.word; g.phase='result'; g.win=win; g.resultText=win?'Отличная реакция!':'В следующий раз получится.';
    finishGame(win,win?'Ты угадал рисунок!':`Правильный ответ: ${g.word}.`);
  }
  function bunkerVote(id) {
    const g=state.game; if (!g || g.type!=='bunker' || g.finished) return;
    const target=g.survivors.find(p=>p.id===Number(id)); if (!target) return;
    const botTargets=g.survivors.filter(p=>!p.you && p.id!==target.id);
    const eliminated=pick([target,...botTargets.slice(0, Math.min(2,botTargets.length))]);
    g.survivors=g.survivors.filter(p=>p.id!==eliminated.id); g.day+=1;
    if (g.survivors.length<=2 || g.day>4) {
      g.finished=true; g.win=g.survivors.some(p=>p.you);
      g.resultText=g.win?`Ты остался в убежище. В нём ${g.survivors.length} выживших.`:'Тебя исключили из убежища. Попробуй изменить тактику.';
      finishGame(g.win,g.resultText);
    } else { toast(`${eliminated.name} покинул убежище.`); save(); render(); }
  }
  function enemyTurn(g) {
    const raw=6+rand(11)+g.level; const damage=Math.max(1,raw-g.block); g.hp=Math.max(0,g.hp-damage); g.block=0; g.turn+=1;
    if (g.hp<=0) { g.finished=true; finishGame(false,'Монстр оказался сильнее. Подготовься и попробуй ещё раз.'); }
  }
  function munchkinAction(action) {
    const g=state.game; if (!g || g.type!=='munchkin' || g.finished) return;
    if (action==='hit') { const dmg=14+rand(9)+g.level*2; g.enemy.hp=Math.max(0,g.enemy.hp-dmg); g.log=`Ты нанёс ${dmg} урона.`; }
    if (action==='block') { g.block=16; g.log='Ты поднял щит. Следующий удар будет слабее.'; }
    if (action==='skill') { if (!g.skillReady) { toast('Навык ещё восстанавливается.'); return; } const dmg=31+rand(12); g.enemy.hp=Math.max(0,g.enemy.hp-dmg); g.skillReady=false; g.log=`Ледяной навык нанёс ${dmg} урона!`; }
    if (action==='potion') { if (g.potions<1 || g.hp>=120) { toast('Зелье сейчас не требуется.'); return; } g.potions-=1; g.hp=Math.min(120,g.hp+38); g.log='Ты восстановил 38 HP.'; }
    if (g.enemy.hp<=0) { g.finished=true; finishGame(true,`${g.enemy.name} повержен!`); return; }
    enemyTurn(g); if (!g.finished) { if (!g.skillReady && g.turn%3===0) g.skillReady=true; save(); render(); }
  }
  function claim(track, level) {
    level=Number(level); const key=track==='premium'?'premium':'free';
    if (state.claimed[key].includes(level)) { toast('Эта награда уже забрана.'); return; }
    if (level>state.passLevel) { toast('Сначала открой этот уровень.'); return; }
    if (key==='premium' && !state.premium) { toast('Премиум-линия пока закрыта.'); return; }
    const r=rewardFor(level,key);
    if (r.type==='gems') state.gems+=r.value;
    else if (r.type==='coins') state.coins+=r.value;
    else state.inventory.push(r.name);
    state.claimed[key].push(level); save(); render(); toast(`Получено: ${r.name}`);
  }
  function claimAll() {
    let count=0;
    for (const track of (state.premium?['free','premium']:['free'])) for (let level=1; level<=state.passLevel; level++) if (!state.claimed[track].includes(level)) { const r=rewardFor(level,track); if(r.type==='gems')state.gems+=r.value;else if(r.type==='coins')state.coins+=r.value;else state.inventory.push(r.name);state.claimed[track].push(level);count++; }
    save(); render(); toast(count?`Забрано наград: ${count}`:'Нет доступных наград.');
  }
  function buyPremium() {
    if (state.premium) { toast('Премиум уже открыт.'); return; }
    if (state.gems<600) { toast('Недостаточно кристаллов.'); return; }
    state.gems-=600; state.premium=true; save(); render(); toast('Премиум-линия открыта!');
  }
  function shopBuy(id) {
    const item=shopItems.find(x=>x.id===id); if(!item)return;
    if (state[item.currency]<item.price) { toast('Не хватает валюты.'); return; }
    state[item.currency]-=item.price; state.inventory.push(item.name);
    if (id==='gem-pack') state.gems+=300;
    save(); render(); toast(`Куплено: ${item.name}`);
  }
  function action(el) {
    const a=el.dataset.action;
    if (a==='navigate') { if (el.dataset.track) state.passFocus=el.dataset.track; state.page=el.dataset.page; save(); render(); if (state.page==='pass' && state.passFocus) setTimeout(()=>document.getElementById(state.passFocus==='premium'?'premium-track':'free-track')?.scrollIntoView({behavior:'smooth',block:'nearest'}),0); return; }
    if (a==='start-game') { startGame(el.dataset.game); return; }
    if (a==='spy-next') { spyNext(); return; }
    if (a==='spy-vote') { spyVote(el.dataset.index); return; }
    if (a==='spy-guess') { spyGuess(el.dataset.location); return; }
    if (a==='croc-guess') { crocGuess(el.dataset.word); return; }
    if (a==='bunker-vote') { bunkerVote(el.dataset.id); return; }
    if (a==='munchkin-hit'||a==='munchkin-block'||a==='munchkin-skill'||a==='munchkin-potion') { munchkinAction(a.replace('munchkin-','')); return; }
    if (a==='pass-page') { state.passPage=Number(el.dataset.pageIndex); save(); render(); return; }
    if (a==='claim-reward') { claim(el.dataset.track,el.dataset.level); return; }
    if (a==='claim-all') { claimAll(); return; }
    if (a==='buy-premium') { buyPremium(); return; }
    if (a==='shop-buy') { shopBuy(el.dataset.id); return; }
    if (a==='select-character') { state.equipped=el.dataset.name; save(); render(); toast(`${state.equipped} выбрана.`); return; }
    if (a==='toggle-setting') { const key=el.dataset.setting; state.settings[key]=!state.settings[key]; save(); render(); return; }
    if (a==='daily-reward') { if (state.dailyClaimed===new Date().toDateString()) { toast('Подарок на сегодня уже получен.'); return; } state.dailyClaimed=new Date().toDateString(); state.coins+=250; state.gems+=25; addXp(80); save(); render(); toast('Подарок получен: +250 монет, +25 кристаллов!'); return; }
    if (a==='rename') { const name=prompt('Новый ник (до 16 символов):',state.playerName); if(name && name.trim()) {state.playerName=name.trim().slice(0,16);save();render();} return; }
    if (a==='confirm-reset') { showModal('Сбросить прогресс?','Все уровни, монеты, кристаллы и награды на этом устройстве будут сброшены. Это действие нельзя отменить.',()=>{localStorage.removeItem(STORAGE_KEY);state=structuredClone(defaultState);render();toast('Прогресс сброшен.');}); return; }
  }
  function showModal(title,text,onConfirm) {
    const wrap=document.createElement('div'); wrap.className='modal-backdrop';
    wrap.innerHTML=`<div class="modal"><h2>${esc(title)}</h2><p>${esc(text)}</p><div class="modal-actions"><button class="soft-btn" data-close>Отмена</button><button class="danger-btn" data-confirm>Подтвердить</button></div></div>`;
    wrap.addEventListener('click',(e)=>{if(e.target===wrap||e.target.closest('[data-close]'))wrap.remove();if(e.target.closest('[data-confirm]')){wrap.remove();onConfirm();}});document.body.appendChild(wrap);
  }
  document.addEventListener('click',(e)=>{const el=e.target.closest('[data-action]');if(el)action(el);});
  document.addEventListener('submit',(e)=>{
    if(e.target.id!=='chatForm')return;e.preventDefault();const input=$('#chatInput');const text=input.value.trim();if(!text)return;
    state.botChat.push({name:'Ты',text});
    const replies=['Удачи в матче! ❄','Я готова, запускай игру!','Попробуем ещё раз? ✨','Видела новую награду в пропуске?'];
    state.botChat.push({name:pick(['Sakura','MikuChan','Rin']),text:pick(replies)});state.botChat=state.botChat.slice(-40);save();render();
  });
  // Cordova plugin locks Android into real landscape mode. The CSS fallback rotates the web UI if a browser blocks the lock.
  function lockLandscape() {
    try {
      if (window.screen && window.screen.orientation && typeof window.screen.orientation.lock==='function') {
        const p=window.screen.orientation.lock('landscape'); if(p && typeof p.catch==='function')p.catch(()=>{});
      }
    } catch (_) {}
  }
  document.addEventListener('deviceready',lockLandscape,false);
  window.addEventListener('load',lockLandscape);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)lockLandscape();});
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
  }
  render();
})();
