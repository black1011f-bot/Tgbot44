import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('www');
const required = ['index.html','styles.css','app.js','manifest.webmanifest','sw.js','assets/winter-hero.webp'];
for (const file of required) {
  const full = path.join(root, file);
  if (!fs.existsSync(full) || fs.statSync(full).size === 0) throw new Error(`Missing or empty file: ${file}`);
}
const js = fs.readFileSync(path.join(root,'app.js'),'utf8');
for (const marker of ['function renderHome','function renderPass','function startGame','function spyVote','function crocGuess','function bunkerVote','function munchkinAction','function claimAll']) {
  if (!js.includes(marker)) throw new Error(`Missing game/app feature: ${marker}`);
}
console.log('NEON LEGENDS source check: OK');
